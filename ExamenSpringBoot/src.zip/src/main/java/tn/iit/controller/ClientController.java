package tn.iit.controller;


import org.springframework.ui.Model;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import tn.iit.entity.Client;
import tn.iit.service.ClientService;

@RequiredArgsConstructor
@RestController

@RequestMapping("/clients")
public class ClientController {
	
	private final ClientService clientService;

	 	@GetMapping("")
		public String check() {
			return "redirect:/clients/";
		}
	 
	    
		@GetMapping({ "/", "/all" })
		public List<Client> findAll() {
			//model.addAttribute("clients", clientService.getAllClients());
			return clientService.getAllClients();
		}
		@ResponseStatus(value=HttpStatus.CREATED)
		@PostMapping(path="/save",consumes = APPLICATION_JSON_VALUE)
	    
	    public Client saveClient(@RequestBody Client client) {
	        return clientService.saveClient(client)  ;
	        
	    }
		@GetMapping(path="/{id}", produces=APPLICATION_JSON_VALUE)
		public Client getClientById(@PathVariable int id) {
			return clientService.findClientById(id);
		}
		/*
		@GetMapping(path="/{id}", produces=APPLICATION_JSON_VALUE)
	    public ResponseEntity<?> getClientById(@PathVariable int id) {
	        Client client = clientService.findClientById(id);

	        if (client == null) {
	            // Retourner une réponse avec un statut 404 si le client n'est pas trouvé
	            return ResponseEntity.status(404).body("Client with ID " + id + " not found");
	        }

	        // Retourner une réponse avec le client en JSON si trouvé
	        return ResponseEntity.ok(client);
	    }*/
		
	    @DeleteMapping("/delete/{cin}")
	    public void deleteClient(@PathVariable Integer cin) {
	        clientService.deleteClient(cin);
	    }
	   @PostMapping(path="/search", produces=APPLICATION_JSON_VALUE)
		public Client search(@RequestParam Integer search, Model model) {
			
			return clientService.findClientById(search);
		}
	    /*@PostMapping(path="/search", produces=APPLICATION_JSON_VALUE)
	    public ResponseEntity<?> search(@RequestParam int search) {
	        Client client = clientService.findClientById(search);

	        if (client == null) {
	            // Retourner une réponse avec un statut 404 si le client n'est pas trouvé
	            return ResponseEntity.status(404).body("Client with ID " + search + " not found");
	        }

	        // Retourner une réponse avec le client en JSON si trouvé
	        return ResponseEntity.ok(client);
	    }*/
	    @PutMapping("/edit/{id}")
	    public Client updateClient(@PathVariable Integer id, @RequestBody Client client) {
	        return clientService.updateClient(id, client);
	    }

	    
}
