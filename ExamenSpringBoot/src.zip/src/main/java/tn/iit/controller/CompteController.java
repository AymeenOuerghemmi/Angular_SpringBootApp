package tn.iit.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import lombok.RequiredArgsConstructor;
import tn.iit.entity.Client;
import tn.iit.entity.Compte;
import tn.iit.service.CompteService;

@RequiredArgsConstructor
@RestController
@RequestMapping(path="/comptes", produces=APPLICATION_JSON_VALUE)
public class CompteController {

	private final CompteService compteService;

	@ResponseBody // retour est Json (utilisation de Jackson)
	@GetMapping("/all-json")
	public List<Compte> findAllJson() {
		return compteService.findAll();
	}

	@GetMapping({ "/", "/all" })
	public String findAll(Model model) {
		model.addAttribute("comptes", compteService.findAll());
		return "comptes";
	}

	@GetMapping("")
	public String check() {
		return "redirect:/comptes/";
	}
	@ResponseStatus
	@PostMapping(path = "/save", consumes = APPLICATION_JSON_VALUE)
	public void save(@RequestBody Compte compte) {
	    compteService.saveOrUpdate(compte);
	}
	/*@ResponseStatus
	@PostMapping(path="/save" , consumes=APPLICATION_JSON_VALUE)
	public void save(@RequestBody Compte compte) {
		//FIXME
		
		compteService.saveOrUpdate(compte);
		
	}*/
	

	/*@PostMapping(path="/update", consumes=APPLICATION_JSON_VALUE)
	public String update(@ModelAttribute Compte compte) {
		compteService.saveOrUpdate(compte);
		return "redirect:/comptes/";
	}*/

	 

	@PostMapping("/search")
	public String search(@RequestParam String search, Model model) {
		model.addAttribute("comptes", compteService.findComptesByClient(search));
		return "comptes";
	}

	@GetMapping("/delete/{rib}")
	public String delete(@PathVariable Integer rib) {
		compteService.delete(rib);
		return "redirect:/comptes/";
	}
	
	@ResponseBody // sans responseBody, spring cherche à retourner une page html
	@PostMapping("/delete-ajax")
	public void deleteAjax(@RequestParam Integer rib) {
		compteService.delete(rib);
	}

}
