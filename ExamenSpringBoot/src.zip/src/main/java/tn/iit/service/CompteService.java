package tn.iit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import tn.iit.dao.ClientRepository;
import tn.iit.dao.CompteRepository;
import tn.iit.entity.Client;
import tn.iit.entity.Compte;
import tn.iit.exception.CompteNotFoundException;


@Transactional
@Service
public class CompteService {
	
	private final ClientService clientService;
	private final CompteRepository compteRepository;
	public CompteService(CompteRepository compteRepository,ClientService clientService) {
		this.compteRepository=compteRepository;
		this.clientService=clientService;
	}

	/*public void saveOrUpdate(Compte compte) {
		Optional<Client> client=clientService.readOrSave(compte.getClient().getCin());
		if (client.isPresent()) {
	        compte.setClient(client.get());
	    }
		compteRepository.save(compte);
	}*/
	public void saveOrUpdate(Compte compte) {
	    // Récupérer ou sauvegarder le client
	    Optional<Client> optionalClient = clientService.readOrSave(compte.getClient());
	    if (optionalClient.isPresent()) {
	        // Associer le client existant ou créé au compte
	        compte.setClient(optionalClient.get());
	    }
	    // Sauvegarder le compte
	    compteRepository.save(compte);
	}
	
	public List<Compte> findAll() {
		return compteRepository.findAll();
	}

	public void delete(Integer rib) {
		compteRepository.deleteById(rib);
	}

	public Compte findById(Integer rib) {
		return compteRepository.findById(rib)
				.orElseThrow(() -> new CompteNotFoundException("compte avec rib " + rib + " not found"));
	}

	public List<Compte> findComptesByClient(String nomClient) {
//FIXME
		return null; // compteRepository.findByNomClientContains(nomClient);
	}
}
