package tn.iit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import tn.iit.dao.ClientRepository;
import tn.iit.entity.Client;
import tn.iit.exception.ClientNotFoundException;

@Service
@Transactional
public class ClientService {
	
	private final ClientRepository clientRepository;
	
	public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }
	
	public Client saveClient(Client client) {
        return clientRepository.save(client);
    }

    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }

    public void deleteClient(Integer cin) {
        clientRepository.deleteById(cin);
    }

    public Client searchClientById(Integer cin) {
    	Optional<Client> optionalClient= clientRepository.findById(cin);
    	if(optionalClient.isPresent()) {
    		return optionalClient.get();
    	}
        return null;
    }
    public Client findClientById(Integer cin) {
		return clientRepository.findById(cin)
				.orElseThrow(() -> new ClientNotFoundException("client avec cin " + cin + " not found"));
	}
    public Client updateClient(Integer id, Client client) {
        Client existingClient = findClientById(id);
        existingClient.setNom(client.getNom());
        existingClient.setPrenom(client.getPrenom());
        return clientRepository.save(existingClient);
    }

    public Optional<Client> readOrSave(Client client) {
        Optional<Client> clientExist = clientRepository.findById(client.getCin());
        if (clientExist.isEmpty()) {
            // Si le client n'existe pas, on le sauvegarde
            clientRepository.save(client);
            return Optional.of(client); // Retourne le nouveau client sauvegardé
        }
        return clientExist; // Retourne le client existant
    }
   
}
